﻿namespace TeamProject_test_v1
{
    partial class 쪽지
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            쪽지_탭컨트롤 = new TabControl();
            tabPage1 = new TabPage();
            groupBox3 = new GroupBox();
            받은쪽지_새로고침_버튼 = new Button();
            받은쪽지검색결과_데이터그리드뷰 = new DataGridView();
            받은쪽지검색_버튼 = new Button();
            받은쪽지검색_콤보박스 = new ComboBox();
            받은쪽지검색_텍스트박스 = new TextBox();
            groupBox2 = new GroupBox();
            받은쪽지내용_리치텍스트박스 = new RichTextBox();
            받은쪽지송신자_텍스트박스 = new TextBox();
            받은쪽지제목_텍스트박스 = new TextBox();
            받은쪽지날짜_라벨 = new Label();
            받은쪽지전달_버튼 = new Button();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            tabPage2 = new TabPage();
            groupBox4 = new GroupBox();
            보낸쪽지내용_리치텍스트박스 = new RichTextBox();
            보낸쪽지송신자_텍스트박스 = new TextBox();
            보낸쪽지제목_텍스트박스 = new TextBox();
            보낸쪽지날짜_라벨 = new Label();
            보낸쪽지전달_버튼 = new Button();
            label2 = new Label();
            label3 = new Label();
            label11 = new Label();
            groupBox1 = new GroupBox();
            보낸쪽지_새로고침_버튼 = new Button();
            보낸쪽지검색결과_데이터그리드뷰 = new DataGridView();
            보낸쪽지검색_버튼 = new Button();
            보낸쪽지검색_콤보박스 = new ComboBox();
            보낸쪽지검색_텍스트박스 = new TextBox();
            panel1 = new Panel();
            쪽지수신자부서_콤보박스 = new ComboBox();
            쪽지내용작성란_리치텍스트박스 = new RichTextBox();
            label13 = new Label();
            쪽지전체송신_체크박스 = new CheckBox();
            쪽지수신자직급이름_콤보박스 = new ComboBox();
            label10 = new Label();
            쪽지제목작성란_텍스트박스 = new TextBox();
            label9 = new Label();
            쪽지보내기_버튼 = new Button();
            label4 = new Label();
            쪽지_탭컨트롤.SuspendLayout();
            tabPage1.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)받은쪽지검색결과_데이터그리드뷰).BeginInit();
            groupBox2.SuspendLayout();
            tabPage2.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)보낸쪽지검색결과_데이터그리드뷰).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // 쪽지_탭컨트롤
            // 
            쪽지_탭컨트롤.Controls.Add(tabPage1);
            쪽지_탭컨트롤.Controls.Add(tabPage2);
            쪽지_탭컨트롤.Location = new Point(19, 18);
            쪽지_탭컨트롤.Name = "쪽지_탭컨트롤";
            쪽지_탭컨트롤.SelectedIndex = 0;
            쪽지_탭컨트롤.Size = new Size(1239, 424);
            쪽지_탭컨트롤.TabIndex = 0;
            쪽지_탭컨트롤.SelectedIndexChanged += 쪽지_탭컨트롤_SelectedIndexChanged;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(groupBox3);
            tabPage1.Controls.Add(groupBox2);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1231, 391);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "받은 쪽지";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(받은쪽지_새로고침_버튼);
            groupBox3.Controls.Add(받은쪽지검색결과_데이터그리드뷰);
            groupBox3.Controls.Add(받은쪽지검색_버튼);
            groupBox3.Controls.Add(받은쪽지검색_콤보박스);
            groupBox3.Controls.Add(받은쪽지검색_텍스트박스);
            groupBox3.Location = new Point(14, 23);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(646, 359);
            groupBox3.TabIndex = 1;
            groupBox3.TabStop = false;
            groupBox3.Text = "쪽지 리스트";
            // 
            // 받은쪽지_새로고침_버튼
            // 
            받은쪽지_새로고침_버튼.Location = new Point(546, 24);
            받은쪽지_새로고침_버튼.Name = "받은쪽지_새로고침_버튼";
            받은쪽지_새로고침_버튼.Size = new Size(94, 44);
            받은쪽지_새로고침_버튼.TabIndex = 10;
            받은쪽지_새로고침_버튼.Text = "새로고침";
            받은쪽지_새로고침_버튼.UseVisualStyleBackColor = true;
            받은쪽지_새로고침_버튼.Click += 받은쪽지_새로고침_버튼_Click;
            // 
            // 받은쪽지검색결과_데이터그리드뷰
            // 
            받은쪽지검색결과_데이터그리드뷰.AllowUserToAddRows = false;
            받은쪽지검색결과_데이터그리드뷰.AllowUserToDeleteRows = false;
            받은쪽지검색결과_데이터그리드뷰.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            받은쪽지검색결과_데이터그리드뷰.Location = new Point(6, 81);
            받은쪽지검색결과_데이터그리드뷰.Name = "받은쪽지검색결과_데이터그리드뷰";
            받은쪽지검색결과_데이터그리드뷰.ReadOnly = true;
            받은쪽지검색결과_데이터그리드뷰.RowHeadersVisible = false;
            받은쪽지검색결과_데이터그리드뷰.RowHeadersWidth = 62;
            받은쪽지검색결과_데이터그리드뷰.RowTemplate.Height = 30;
            받은쪽지검색결과_데이터그리드뷰.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            받은쪽지검색결과_데이터그리드뷰.Size = new Size(634, 262);
            받은쪽지검색결과_데이터그리드뷰.TabIndex = 1;
            받은쪽지검색결과_데이터그리드뷰.CellClick += 받은쪽지검색결과_데이터그리드뷰_CellClick;
            // 
            // 받은쪽지검색_버튼
            // 
            받은쪽지검색_버튼.Location = new Point(376, 24);
            받은쪽지검색_버튼.Name = "받은쪽지검색_버튼";
            받은쪽지검색_버튼.Size = new Size(65, 44);
            받은쪽지검색_버튼.TabIndex = 9;
            받은쪽지검색_버튼.Text = "검색";
            받은쪽지검색_버튼.UseVisualStyleBackColor = true;
            받은쪽지검색_버튼.Click += 받은쪽지검색_버튼_Click;
            // 
            // 받은쪽지검색_콤보박스
            // 
            받은쪽지검색_콤보박스.Font = new Font("굴림", 10F, FontStyle.Regular, GraphicsUnit.Point);
            받은쪽지검색_콤보박스.FormattingEnabled = true;
            받은쪽지검색_콤보박스.Location = new Point(14, 36);
            받은쪽지검색_콤보박스.Name = "받은쪽지검색_콤보박스";
            받은쪽지검색_콤보박스.Size = new Size(119, 25);
            받은쪽지검색_콤보박스.TabIndex = 8;
            받은쪽지검색_콤보박스.Text = "검색조건";
            // 
            // 받은쪽지검색_텍스트박스
            // 
            받은쪽지검색_텍스트박스.Font = new Font("굴림", 10F, FontStyle.Regular, GraphicsUnit.Point);
            받은쪽지검색_텍스트박스.Location = new Point(139, 34);
            받은쪽지검색_텍스트박스.Name = "받은쪽지검색_텍스트박스";
            받은쪽지검색_텍스트박스.Size = new Size(231, 27);
            받은쪽지검색_텍스트박스.TabIndex = 7;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(받은쪽지내용_리치텍스트박스);
            groupBox2.Controls.Add(받은쪽지송신자_텍스트박스);
            groupBox2.Controls.Add(받은쪽지제목_텍스트박스);
            groupBox2.Controls.Add(받은쪽지날짜_라벨);
            groupBox2.Controls.Add(받은쪽지전달_버튼);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label8);
            groupBox2.Location = new Point(686, 23);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(503, 359);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            groupBox2.Text = "상세 내용";
            // 
            // 받은쪽지내용_리치텍스트박스
            // 
            받은쪽지내용_리치텍스트박스.BorderStyle = BorderStyle.None;
            받은쪽지내용_리치텍스트박스.Location = new Point(80, 201);
            받은쪽지내용_리치텍스트박스.Name = "받은쪽지내용_리치텍스트박스";
            받은쪽지내용_리치텍스트박스.ReadOnly = true;
            받은쪽지내용_리치텍스트박스.Size = new Size(399, 142);
            받은쪽지내용_리치텍스트박스.TabIndex = 6;
            받은쪽지내용_리치텍스트박스.Text = "";
            // 
            // 받은쪽지송신자_텍스트박스
            // 
            받은쪽지송신자_텍스트박스.BorderStyle = BorderStyle.None;
            받은쪽지송신자_텍스트박스.Location = new Point(80, 122);
            받은쪽지송신자_텍스트박스.Name = "받은쪽지송신자_텍스트박스";
            받은쪽지송신자_텍스트박스.ReadOnly = true;
            받은쪽지송신자_텍스트박스.Size = new Size(399, 20);
            받은쪽지송신자_텍스트박스.TabIndex = 5;
            // 
            // 받은쪽지제목_텍스트박스
            // 
            받은쪽지제목_텍스트박스.BorderStyle = BorderStyle.None;
            받은쪽지제목_텍스트박스.Location = new Point(80, 76);
            받은쪽지제목_텍스트박스.Name = "받은쪽지제목_텍스트박스";
            받은쪽지제목_텍스트박스.ReadOnly = true;
            받은쪽지제목_텍스트박스.Size = new Size(399, 20);
            받은쪽지제목_텍스트박스.TabIndex = 4;
            // 
            // 받은쪽지날짜_라벨
            // 
            받은쪽지날짜_라벨.AutoSize = true;
            받은쪽지날짜_라벨.Font = new Font("굴림", 8F, FontStyle.Regular, GraphicsUnit.Point);
            받은쪽지날짜_라벨.Location = new Point(19, 168);
            받은쪽지날짜_라벨.Name = "받은쪽지날짜_라벨";
            받은쪽지날짜_라벨.Size = new Size(37, 14);
            받은쪽지날짜_라벨.TabIndex = 3;
            받은쪽지날짜_라벨.Text = "Date";
            // 
            // 받은쪽지전달_버튼
            // 
            받은쪽지전달_버튼.Location = new Point(353, 19);
            받은쪽지전달_버튼.Name = "받은쪽지전달_버튼";
            받은쪽지전달_버튼.Size = new Size(126, 44);
            받은쪽지전달_버튼.TabIndex = 5;
            받은쪽지전달_버튼.Text = "전달";
            받은쪽지전달_버튼.UseVisualStyleBackColor = true;
            받은쪽지전달_버튼.Click += 받은쪽지전달_버튼_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(19, 126);
            label6.Name = "label6";
            label6.Size = new Size(54, 20);
            label6.TabIndex = 2;
            label6.Text = "송신자";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(19, 201);
            label7.Name = "label7";
            label7.Size = new Size(39, 20);
            label7.TabIndex = 1;
            label7.Text = "내용";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(19, 81);
            label8.Name = "label8";
            label8.Size = new Size(39, 20);
            label8.TabIndex = 0;
            label8.Text = "제목";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(groupBox4);
            tabPage2.Controls.Add(groupBox1);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1231, 391);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "보낸 쪽지";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(보낸쪽지내용_리치텍스트박스);
            groupBox4.Controls.Add(보낸쪽지송신자_텍스트박스);
            groupBox4.Controls.Add(보낸쪽지제목_텍스트박스);
            groupBox4.Controls.Add(보낸쪽지날짜_라벨);
            groupBox4.Controls.Add(보낸쪽지전달_버튼);
            groupBox4.Controls.Add(label2);
            groupBox4.Controls.Add(label3);
            groupBox4.Controls.Add(label11);
            groupBox4.Location = new Point(687, 23);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(502, 362);
            groupBox4.TabIndex = 7;
            groupBox4.TabStop = false;
            groupBox4.Text = "상세 내용";
            // 
            // 보낸쪽지내용_리치텍스트박스
            // 
            보낸쪽지내용_리치텍스트박스.BorderStyle = BorderStyle.None;
            보낸쪽지내용_리치텍스트박스.Location = new Point(80, 205);
            보낸쪽지내용_리치텍스트박스.Name = "보낸쪽지내용_리치텍스트박스";
            보낸쪽지내용_리치텍스트박스.ReadOnly = true;
            보낸쪽지내용_리치텍스트박스.Size = new Size(399, 139);
            보낸쪽지내용_리치텍스트박스.TabIndex = 6;
            보낸쪽지내용_리치텍스트박스.Text = "";
            // 
            // 보낸쪽지송신자_텍스트박스
            // 
            보낸쪽지송신자_텍스트박스.BorderStyle = BorderStyle.None;
            보낸쪽지송신자_텍스트박스.Location = new Point(80, 126);
            보낸쪽지송신자_텍스트박스.Name = "보낸쪽지송신자_텍스트박스";
            보낸쪽지송신자_텍스트박스.ReadOnly = true;
            보낸쪽지송신자_텍스트박스.Size = new Size(399, 20);
            보낸쪽지송신자_텍스트박스.TabIndex = 5;
            // 
            // 보낸쪽지제목_텍스트박스
            // 
            보낸쪽지제목_텍스트박스.BorderStyle = BorderStyle.None;
            보낸쪽지제목_텍스트박스.Location = new Point(80, 80);
            보낸쪽지제목_텍스트박스.Name = "보낸쪽지제목_텍스트박스";
            보낸쪽지제목_텍스트박스.ReadOnly = true;
            보낸쪽지제목_텍스트박스.Size = new Size(399, 20);
            보낸쪽지제목_텍스트박스.TabIndex = 4;
            // 
            // 보낸쪽지날짜_라벨
            // 
            보낸쪽지날짜_라벨.AutoSize = true;
            보낸쪽지날짜_라벨.Font = new Font("굴림", 8F, FontStyle.Regular, GraphicsUnit.Point);
            보낸쪽지날짜_라벨.Location = new Point(19, 172);
            보낸쪽지날짜_라벨.Name = "보낸쪽지날짜_라벨";
            보낸쪽지날짜_라벨.Size = new Size(37, 14);
            보낸쪽지날짜_라벨.TabIndex = 3;
            보낸쪽지날짜_라벨.Text = "Date";
            // 
            // 보낸쪽지전달_버튼
            // 
            보낸쪽지전달_버튼.Location = new Point(353, 22);
            보낸쪽지전달_버튼.Name = "보낸쪽지전달_버튼";
            보낸쪽지전달_버튼.Size = new Size(126, 44);
            보낸쪽지전달_버튼.TabIndex = 5;
            보낸쪽지전달_버튼.Text = "전달";
            보낸쪽지전달_버튼.UseVisualStyleBackColor = true;
            보낸쪽지전달_버튼.Click += 보낸쪽지전달_버튼_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 130);
            label2.Name = "label2";
            label2.Size = new Size(54, 20);
            label2.TabIndex = 2;
            label2.Text = "송신자";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 205);
            label3.Name = "label3";
            label3.Size = new Size(39, 20);
            label3.TabIndex = 1;
            label3.Text = "내용";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 85);
            label11.Name = "label11";
            label11.Size = new Size(39, 20);
            label11.TabIndex = 0;
            label11.Text = "제목";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(보낸쪽지_새로고침_버튼);
            groupBox1.Controls.Add(보낸쪽지검색결과_데이터그리드뷰);
            groupBox1.Controls.Add(보낸쪽지검색_버튼);
            groupBox1.Controls.Add(보낸쪽지검색_콤보박스);
            groupBox1.Controls.Add(보낸쪽지검색_텍스트박스);
            groupBox1.Location = new Point(14, 23);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(646, 362);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "쪽지 리스트";
            // 
            // 보낸쪽지_새로고침_버튼
            // 
            보낸쪽지_새로고침_버튼.Location = new Point(546, 22);
            보낸쪽지_새로고침_버튼.Name = "보낸쪽지_새로고침_버튼";
            보낸쪽지_새로고침_버튼.Size = new Size(94, 44);
            보낸쪽지_새로고침_버튼.TabIndex = 11;
            보낸쪽지_새로고침_버튼.Text = "새로고침";
            보낸쪽지_새로고침_버튼.UseVisualStyleBackColor = true;
            보낸쪽지_새로고침_버튼.Click += 보낸쪽지_새로고침_버튼_Click;
            // 
            // 보낸쪽지검색결과_데이터그리드뷰
            // 
            보낸쪽지검색결과_데이터그리드뷰.AllowUserToAddRows = false;
            보낸쪽지검색결과_데이터그리드뷰.AllowUserToDeleteRows = false;
            보낸쪽지검색결과_데이터그리드뷰.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            보낸쪽지검색결과_데이터그리드뷰.Location = new Point(6, 81);
            보낸쪽지검색결과_데이터그리드뷰.Name = "보낸쪽지검색결과_데이터그리드뷰";
            보낸쪽지검색결과_데이터그리드뷰.ReadOnly = true;
            보낸쪽지검색결과_데이터그리드뷰.RowHeadersVisible = false;
            보낸쪽지검색결과_데이터그리드뷰.RowHeadersWidth = 62;
            보낸쪽지검색결과_데이터그리드뷰.RowTemplate.Height = 30;
            보낸쪽지검색결과_데이터그리드뷰.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            보낸쪽지검색결과_데이터그리드뷰.Size = new Size(634, 263);
            보낸쪽지검색결과_데이터그리드뷰.TabIndex = 1;
            보낸쪽지검색결과_데이터그리드뷰.CellClick += 보낸쪽지검색결과_데이터그리드뷰_CellClick;
            // 
            // 보낸쪽지검색_버튼
            // 
            보낸쪽지검색_버튼.Location = new Point(374, 22);
            보낸쪽지검색_버튼.Name = "보낸쪽지검색_버튼";
            보낸쪽지검색_버튼.Size = new Size(65, 44);
            보낸쪽지검색_버튼.TabIndex = 9;
            보낸쪽지검색_버튼.Text = "검색";
            보낸쪽지검색_버튼.UseVisualStyleBackColor = true;
            보낸쪽지검색_버튼.Click += 보낸쪽지검색_버튼_Click;
            // 
            // 보낸쪽지검색_콤보박스
            // 
            보낸쪽지검색_콤보박스.Font = new Font("굴림", 10F, FontStyle.Regular, GraphicsUnit.Point);
            보낸쪽지검색_콤보박스.FormattingEnabled = true;
            보낸쪽지검색_콤보박스.Location = new Point(14, 29);
            보낸쪽지검색_콤보박스.Name = "보낸쪽지검색_콤보박스";
            보낸쪽지검색_콤보박스.Size = new Size(119, 25);
            보낸쪽지검색_콤보박스.TabIndex = 3;
            보낸쪽지검색_콤보박스.Text = "검색조건";
            // 
            // 보낸쪽지검색_텍스트박스
            // 
            보낸쪽지검색_텍스트박스.Font = new Font("굴림", 10F, FontStyle.Regular, GraphicsUnit.Point);
            보낸쪽지검색_텍스트박스.Location = new Point(139, 29);
            보낸쪽지검색_텍스트박스.Name = "보낸쪽지검색_텍스트박스";
            보낸쪽지검색_텍스트박스.Size = new Size(231, 27);
            보낸쪽지검색_텍스트박스.TabIndex = 7;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlLight;
            panel1.Controls.Add(쪽지수신자부서_콤보박스);
            panel1.Controls.Add(쪽지내용작성란_리치텍스트박스);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(쪽지전체송신_체크박스);
            panel1.Controls.Add(쪽지수신자직급이름_콤보박스);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(쪽지제목작성란_텍스트박스);
            panel1.Controls.Add(label9);
            panel1.Location = new Point(23, 498);
            panel1.Name = "panel1";
            panel1.Size = new Size(1231, 194);
            panel1.TabIndex = 1;
            // 
            // 쪽지수신자부서_콤보박스
            // 
            쪽지수신자부서_콤보박스.FormattingEnabled = true;
            쪽지수신자부서_콤보박스.Location = new Point(676, 24);
            쪽지수신자부서_콤보박스.Name = "쪽지수신자부서_콤보박스";
            쪽지수신자부서_콤보박스.Size = new Size(154, 28);
            쪽지수신자부서_콤보박스.TabIndex = 10;
            쪽지수신자부서_콤보박스.Text = "부서";
            쪽지수신자부서_콤보박스.SelectedIndexChanged += 쪽지수신자부서_콤보박스_SelectedIndexChanged;
            // 
            // 쪽지내용작성란_리치텍스트박스
            // 
            쪽지내용작성란_리치텍스트박스.Location = new Point(83, 71);
            쪽지내용작성란_리치텍스트박스.Name = "쪽지내용작성란_리치텍스트박스";
            쪽지내용작성란_리치텍스트박스.Size = new Size(1108, 106);
            쪽지내용작성란_리치텍스트박스.TabIndex = 9;
            쪽지내용작성란_리치텍스트박스.Text = "";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(22, 71);
            label13.Name = "label13";
            label13.Size = new Size(39, 20);
            label13.TabIndex = 8;
            label13.Text = "내용";
            // 
            // 쪽지전체송신_체크박스
            // 
            쪽지전체송신_체크박스.AutoSize = true;
            쪽지전체송신_체크박스.Enabled = false;
            쪽지전체송신_체크박스.Location = new Point(1093, 27);
            쪽지전체송신_체크박스.Name = "쪽지전체송신_체크박스";
            쪽지전체송신_체크박스.Size = new Size(96, 24);
            쪽지전체송신_체크박스.TabIndex = 4;
            쪽지전체송신_체크박스.Text = "전체 송신";
            쪽지전체송신_체크박스.UseVisualStyleBackColor = true;
            // 
            // 쪽지수신자직급이름_콤보박스
            // 
            쪽지수신자직급이름_콤보박스.Enabled = false;
            쪽지수신자직급이름_콤보박스.FormattingEnabled = true;
            쪽지수신자직급이름_콤보박스.Location = new Point(845, 24);
            쪽지수신자직급이름_콤보박스.Name = "쪽지수신자직급이름_콤보박스";
            쪽지수신자직급이름_콤보박스.Size = new Size(233, 28);
            쪽지수신자직급이름_콤보박스.TabIndex = 3;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(606, 30);
            label10.Name = "label10";
            label10.Size = new Size(54, 20);
            label10.TabIndex = 2;
            label10.Text = "수신자";
            // 
            // 쪽지제목작성란_텍스트박스
            // 
            쪽지제목작성란_텍스트박스.Location = new Point(83, 24);
            쪽지제목작성란_텍스트박스.Name = "쪽지제목작성란_텍스트박스";
            쪽지제목작성란_텍스트박스.Size = new Size(388, 27);
            쪽지제목작성란_텍스트박스.TabIndex = 1;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(22, 28);
            label9.Name = "label9";
            label9.Size = new Size(39, 20);
            label9.TabIndex = 0;
            label9.Text = "제목";
            // 
            // 쪽지보내기_버튼
            // 
            쪽지보내기_버튼.Location = new Point(1128, 448);
            쪽지보내기_버튼.Name = "쪽지보내기_버튼";
            쪽지보내기_버튼.Size = new Size(126, 44);
            쪽지보내기_버튼.TabIndex = 4;
            쪽지보내기_버튼.Text = "보내기";
            쪽지보내기_버튼.UseVisualStyleBackColor = true;
            쪽지보내기_버튼.Click += 쪽지보내기_버튼_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("굴림", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(19, 456);
            label4.Name = "label4";
            label4.Size = new Size(144, 24);
            label4.TabIndex = 7;
            label4.Text = "쪽지 작성란";
            // 
            // 쪽지
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1280, 720);
            ControlBox = false;
            Controls.Add(label4);
            Controls.Add(쪽지보내기_버튼);
            Controls.Add(panel1);
            Controls.Add(쪽지_탭컨트롤);
            FormBorderStyle = FormBorderStyle.None;
            Name = "쪽지";
            쪽지_탭컨트롤.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)받은쪽지검색결과_데이터그리드뷰).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            tabPage2.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)보낸쪽지검색결과_데이터그리드뷰).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TabControl 쪽지_탭컨트롤;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox 받은쪽지내용_리치텍스트박스;
        private System.Windows.Forms.TextBox 받은쪽지송신자_텍스트박스;
        private System.Windows.Forms.TextBox 받은쪽지제목_텍스트박스;
        private System.Windows.Forms.Label 받은쪽지날짜_라벨;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button 받은쪽지전달_버튼;
        private System.Windows.Forms.DataGridView 받은쪽지검색결과_데이터그리드뷰;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button 쪽지보내기_버튼;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button 받은쪽지검색_버튼;
        private System.Windows.Forms.ComboBox 받은쪽지검색_콤보박스;
        private System.Windows.Forms.TextBox 받은쪽지검색_텍스트박스;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RichTextBox 보낸쪽지내용_리치텍스트박스;
        private System.Windows.Forms.TextBox 보낸쪽지송신자_텍스트박스;
        private System.Windows.Forms.TextBox 보낸쪽지제목_텍스트박스;
        private System.Windows.Forms.Label 보낸쪽지날짜_라벨;
        private System.Windows.Forms.Button 보낸쪽지전달_버튼;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView 보낸쪽지검색결과_데이터그리드뷰;
        private System.Windows.Forms.Button 보낸쪽지검색_버튼;
        private System.Windows.Forms.ComboBox 보낸쪽지검색_콤보박스;
        private System.Windows.Forms.TextBox 보낸쪽지검색_텍스트박스;
        private System.Windows.Forms.CheckBox 쪽지전체송신_체크박스;
        private System.Windows.Forms.ComboBox 쪽지수신자직급이름_콤보박스;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox 쪽지제목작성란_텍스트박스;
        private System.Windows.Forms.RichTextBox 쪽지내용작성란_리치텍스트박스;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox 쪽지수신자부서_콤보박스;
        private System.Windows.Forms.Button 받은쪽지_새로고침_버튼;
        private System.Windows.Forms.Button 보낸쪽지_새로고침_버튼;
    }
}

