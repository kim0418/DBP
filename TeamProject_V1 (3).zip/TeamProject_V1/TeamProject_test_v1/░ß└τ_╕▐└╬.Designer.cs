﻿namespace TeamProject_test_v1
{
    partial class 결재_메인
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            초기화_버튼 = new Button();
            결재_등록_내역_리스트_콤보박스 = new ComboBox();
            panel1 = new Panel();
            조회_2단계_결재자_코맨트_텍스트박스 = new TextBox();
            label8 = new Label();
            조회_단계1_결재자_코맨트_텍스트박스 = new TextBox();
            조회_1단계_결재자코맨트_라벨 = new Label();
            등록_결재_상세정보_텍스트박스 = new TextBox();
            결재_제목_텍스트박스 = new TextBox();
            label1 = new Label();
            결재_코멘트 = new Label();
            label2 = new Label();
            결재자2_콤보박스 = new ComboBox();
            label3 = new Label();
            결재자1_콤보박스 = new ComboBox();
            label4 = new Label();
            관련_업무_콤보박스 = new ComboBox();
            불러오기_버튼 = new Button();
            신규_결재_등록 = new Label();
            결재_등록_내역_그리드뷰 = new DataGridView();
            삭제_버튼 = new Button();
            등록_버튼 = new Button();
            결재_등록_내역 = new Label();
            tabPage2 = new TabPage();
            panel3 = new Panel();
            승인_반려_불러오기_버튼 = new Button();
            panel2 = new Panel();
            승인_반려_2단계_결재자_코맨트_텍스트박스 = new TextBox();
            label9 = new Label();
            승인_반려_1단계_결재자_코맨트_텍스트박스 = new TextBox();
            label10 = new Label();
            결재_코맨트_텍스트박스 = new TextBox();
            상세정보_제목_텍스트박스 = new TextBox();
            결재자2_텍스트박스 = new TextBox();
            label6 = new Label();
            결재자1_텍스트박스 = new TextBox();
            관련_업무 = new Label();
            관련_업무_텍스트박스 = new TextBox();
            결재자1 = new Label();
            결재자2 = new Label();
            label5 = new Label();
            결재리스트_선택_콤보박스 = new ComboBox();
            결재_상세_정보 = new Label();
            결재해야할_내역_그리드뷰 = new DataGridView();
            승인_버튼 = new Button();
            반려_버튼 = new Button();
            결재_해야할_리스트 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)결재_등록_내역_그리드뷰).BeginInit();
            tabPage2.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)결재해야할_내역_그리드뷰).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(4, 6);
            tabControl1.Margin = new Padding(4, 5, 4, 5);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1270, 710);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(초기화_버튼);
            tabPage1.Controls.Add(결재_등록_내역_리스트_콤보박스);
            tabPage1.Controls.Add(panel1);
            tabPage1.Controls.Add(불러오기_버튼);
            tabPage1.Controls.Add(신규_결재_등록);
            tabPage1.Controls.Add(결재_등록_내역_그리드뷰);
            tabPage1.Controls.Add(삭제_버튼);
            tabPage1.Controls.Add(등록_버튼);
            tabPage1.Controls.Add(결재_등록_내역);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Margin = new Padding(4, 5, 4, 5);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(4, 5, 4, 5);
            tabPage1.Size = new Size(1262, 677);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "결재 조회";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // 초기화_버튼
            // 
            초기화_버튼.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            초기화_버튼.Location = new Point(983, 393);
            초기화_버튼.Margin = new Padding(4, 5, 4, 5);
            초기화_버튼.Name = "초기화_버튼";
            초기화_버튼.Size = new Size(126, 30);
            초기화_버튼.TabIndex = 55;
            초기화_버튼.Text = "초기화";
            초기화_버튼.UseVisualStyleBackColor = true;
            초기화_버튼.Click += 초기화_버튼_Click;
            // 
            // 결재_등록_내역_리스트_콤보박스
            // 
            결재_등록_내역_리스트_콤보박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재_등록_내역_리스트_콤보박스.FormattingEnabled = true;
            결재_등록_내역_리스트_콤보박스.Items.AddRange(new object[] { "전체", "결재 중", "결재 완료" });
            결재_등록_내역_리스트_콤보박스.Location = new Point(826, 21);
            결재_등록_내역_리스트_콤보박스.Margin = new Padding(4, 5, 4, 5);
            결재_등록_내역_리스트_콤보박스.Name = "결재_등록_내역_리스트_콤보박스";
            결재_등록_내역_리스트_콤보박스.Size = new Size(169, 30);
            결재_등록_내역_리스트_콤보박스.TabIndex = 53;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkGray;
            panel1.Controls.Add(조회_2단계_결재자_코맨트_텍스트박스);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(조회_단계1_결재자_코맨트_텍스트박스);
            panel1.Controls.Add(조회_1단계_결재자코맨트_라벨);
            panel1.Controls.Add(등록_결재_상세정보_텍스트박스);
            panel1.Controls.Add(결재_제목_텍스트박스);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(결재_코멘트);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(결재자2_콤보박스);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(결재자1_콤보박스);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(관련_업무_콤보박스);
            panel1.Location = new Point(17, 432);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(1226, 235);
            panel1.TabIndex = 33;
            // 
            // 조회_2단계_결재자_코맨트_텍스트박스
            // 
            조회_2단계_결재자_코맨트_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            조회_2단계_결재자_코맨트_텍스트박스.Location = new Point(830, 112);
            조회_2단계_결재자_코맨트_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            조회_2단계_결재자_코맨트_텍스트박스.Multiline = true;
            조회_2단계_결재자_코맨트_텍스트박스.Name = "조회_2단계_결재자_코맨트_텍스트박스";
            조회_2단계_결재자_코맨트_텍스트박스.ReadOnly = true;
            조회_2단계_결재자_코맨트_텍스트박스.Size = new Size(378, 110);
            조회_2단계_결재자_코맨트_텍스트박스.TabIndex = 35;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.AppWorkspace;
            label8.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(830, 81);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(295, 19);
            label8.TabIndex = 34;
            label8.Text = "2단계 결재자 코맨트 ( 입력 불가 )";
            // 
            // 조회_단계1_결재자_코맨트_텍스트박스
            // 
            조회_단계1_결재자_코맨트_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            조회_단계1_결재자_코맨트_텍스트박스.Location = new Point(427, 112);
            조회_단계1_결재자_코맨트_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            조회_단계1_결재자_코맨트_텍스트박스.Multiline = true;
            조회_단계1_결재자_코맨트_텍스트박스.Name = "조회_단계1_결재자_코맨트_텍스트박스";
            조회_단계1_결재자_코맨트_텍스트박스.ReadOnly = true;
            조회_단계1_결재자_코맨트_텍스트박스.Size = new Size(378, 110);
            조회_단계1_결재자_코맨트_텍스트박스.TabIndex = 33;
            // 
            // 조회_1단계_결재자코맨트_라벨
            // 
            조회_1단계_결재자코맨트_라벨.AutoSize = true;
            조회_1단계_결재자코맨트_라벨.BackColor = SystemColors.AppWorkspace;
            조회_1단계_결재자코맨트_라벨.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            조회_1단계_결재자코맨트_라벨.Location = new Point(427, 81);
            조회_1단계_결재자코맨트_라벨.Margin = new Padding(4, 0, 4, 0);
            조회_1단계_결재자코맨트_라벨.Name = "조회_1단계_결재자코맨트_라벨";
            조회_1단계_결재자코맨트_라벨.Size = new Size(295, 19);
            조회_1단계_결재자코맨트_라벨.TabIndex = 32;
            조회_1단계_결재자코맨트_라벨.Text = "1단계 결재자 코맨트 ( 입력 불가 )";
            // 
            // 등록_결재_상세정보_텍스트박스
            // 
            등록_결재_상세정보_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            등록_결재_상세정보_텍스트박스.Location = new Point(21, 112);
            등록_결재_상세정보_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            등록_결재_상세정보_텍스트박스.Multiline = true;
            등록_결재_상세정보_텍스트박스.Name = "등록_결재_상세정보_텍스트박스";
            등록_결재_상세정보_텍스트박스.Size = new Size(378, 110);
            등록_결재_상세정보_텍스트박스.TabIndex = 31;
            // 
            // 결재_제목_텍스트박스
            // 
            결재_제목_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재_제목_텍스트박스.Location = new Point(21, 39);
            결재_제목_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재_제목_텍스트박스.Name = "결재_제목_텍스트박스";
            결재_제목_텍스트박스.Size = new Size(251, 32);
            결재_제목_텍스트박스.TabIndex = 22;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.AppWorkspace;
            label1.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(21, 10);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(147, 19);
            label1.TabIndex = 23;
            label1.Text = "결재 제목 (필수)";
            // 
            // 결재_코멘트
            // 
            결재_코멘트.AutoSize = true;
            결재_코멘트.BackColor = SystemColors.AppWorkspace;
            결재_코멘트.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            결재_코멘트.Location = new Point(17, 81);
            결재_코멘트.Margin = new Padding(4, 0, 4, 0);
            결재_코멘트.Name = "결재_코멘트";
            결재_코멘트.Size = new Size(129, 19);
            결재_코멘트.TabIndex = 30;
            결재_코멘트.Text = "결재 상세정보";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.AppWorkspace;
            label2.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(336, 10);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(147, 19);
            label2.TabIndex = 24;
            label2.Text = "관련 업무 (필수)";
            // 
            // 결재자2_콤보박스
            // 
            결재자2_콤보박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재자2_콤보박스.FormattingEnabled = true;
            결재자2_콤보박스.Location = new Point(957, 41);
            결재자2_콤보박스.Margin = new Padding(4, 5, 4, 5);
            결재자2_콤보박스.Name = "결재자2_콤보박스";
            결재자2_콤보박스.Size = new Size(251, 30);
            결재자2_콤보박스.TabIndex = 29;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.AppWorkspace;
            label3.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(653, 10);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(176, 19);
            label3.TabIndex = 25;
            label3.Text = "1단계 결재자 (필수)";
            // 
            // 결재자1_콤보박스
            // 
            결재자1_콤보박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재자1_콤보박스.FormattingEnabled = true;
            결재자1_콤보박스.Location = new Point(652, 41);
            결재자1_콤보박스.Margin = new Padding(4, 5, 4, 5);
            결재자1_콤보박스.Name = "결재자1_콤보박스";
            결재자1_콤보박스.Size = new Size(251, 30);
            결재자1_콤보박스.TabIndex = 28;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.AppWorkspace;
            label4.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(957, 10);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(176, 19);
            label4.TabIndex = 26;
            label4.Text = "2단계 결재자 (필수)";
            // 
            // 관련_업무_콤보박스
            // 
            관련_업무_콤보박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            관련_업무_콤보박스.FormattingEnabled = true;
            관련_업무_콤보박스.Location = new Point(335, 41);
            관련_업무_콤보박스.Margin = new Padding(4, 5, 4, 5);
            관련_업무_콤보박스.Name = "관련_업무_콤보박스";
            관련_업무_콤보박스.Size = new Size(251, 30);
            관련_업무_콤보박스.TabIndex = 27;
            // 
            // 불러오기_버튼
            // 
            불러오기_버튼.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            불러오기_버튼.Location = new Point(1015, 19);
            불러오기_버튼.Margin = new Padding(4, 5, 4, 5);
            불러오기_버튼.Name = "불러오기_버튼";
            불러오기_버튼.Size = new Size(110, 33);
            불러오기_버튼.TabIndex = 32;
            불러오기_버튼.Text = "불러오기";
            불러오기_버튼.UseVisualStyleBackColor = true;
            불러오기_버튼.Click += 불러오기_버튼_Click;
            // 
            // 신규_결재_등록
            // 
            신규_결재_등록.AutoSize = true;
            신규_결재_등록.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            신규_결재_등록.Location = new Point(17, 393);
            신규_결재_등록.Margin = new Padding(4, 0, 4, 0);
            신규_결재_등록.Name = "신규_결재_등록";
            신규_결재_등록.Size = new Size(156, 22);
            신규_결재_등록.TabIndex = 20;
            신규_결재_등록.Text = "신규 결재 등록";
            // 
            // 결재_등록_내역_그리드뷰
            // 
            결재_등록_내역_그리드뷰.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            결재_등록_내역_그리드뷰.Location = new Point(17, 55);
            결재_등록_내역_그리드뷰.Margin = new Padding(4, 5, 4, 5);
            결재_등록_내역_그리드뷰.Name = "결재_등록_내역_그리드뷰";
            결재_등록_내역_그리드뷰.RowHeadersWidth = 51;
            결재_등록_내역_그리드뷰.RowTemplate.Height = 23;
            결재_등록_내역_그리드뷰.Size = new Size(601, 323);
            결재_등록_내역_그리드뷰.TabIndex = 19;
            결재_등록_내역_그리드뷰.CellClick += 결재_내역_그리드뷰_CellClick;
            // 
            // 삭제_버튼
            // 
            삭제_버튼.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            삭제_버튼.Location = new Point(1133, 21);
            삭제_버튼.Margin = new Padding(4, 5, 4, 5);
            삭제_버튼.Name = "삭제_버튼";
            삭제_버튼.Size = new Size(110, 32);
            삭제_버튼.TabIndex = 18;
            삭제_버튼.Text = "삭제";
            삭제_버튼.UseVisualStyleBackColor = true;
            삭제_버튼.Click += 삭제_버튼_Click;
            // 
            // 등록_버튼
            // 
            등록_버튼.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            등록_버튼.Location = new Point(1117, 393);
            등록_버튼.Margin = new Padding(4, 5, 4, 5);
            등록_버튼.Name = "등록_버튼";
            등록_버튼.Size = new Size(126, 30);
            등록_버튼.TabIndex = 17;
            등록_버튼.Text = "등록";
            등록_버튼.UseVisualStyleBackColor = true;
            등록_버튼.Click += 등록_버튼_Click;
            // 
            // 결재_등록_내역
            // 
            결재_등록_내역.AutoSize = true;
            결재_등록_내역.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재_등록_내역.Location = new Point(13, 21);
            결재_등록_내역.Margin = new Padding(4, 0, 4, 0);
            결재_등록_내역.Name = "결재_등록_내역";
            결재_등록_내역.Size = new Size(156, 22);
            결재_등록_내역.TabIndex = 16;
            결재_등록_내역.Text = "결재 등록 내역";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(panel3);
            tabPage2.Controls.Add(승인_반려_불러오기_버튼);
            tabPage2.Controls.Add(panel2);
            tabPage2.Controls.Add(결재리스트_선택_콤보박스);
            tabPage2.Controls.Add(결재_상세_정보);
            tabPage2.Controls.Add(결재해야할_내역_그리드뷰);
            tabPage2.Controls.Add(승인_버튼);
            tabPage2.Controls.Add(반려_버튼);
            tabPage2.Controls.Add(결재_해야할_리스트);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Margin = new Padding(4, 5, 4, 5);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4, 5, 4, 5);
            tabPage2.Size = new Size(1262, 677);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "결재해야 할 리스트";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            panel3.Location = new Point(669, 51);
            panel3.Name = "panel3";
            panel3.Size = new Size(574, 323);
            panel3.TabIndex = 55;
            // 
            // 승인_반려_불러오기_버튼
            // 
            승인_반려_불러오기_버튼.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            승인_반려_불러오기_버튼.Location = new Point(1118, 13);
            승인_반려_불러오기_버튼.Margin = new Padding(4, 5, 4, 5);
            승인_반려_불러오기_버튼.Name = "승인_반려_불러오기_버튼";
            승인_반려_불러오기_버튼.Size = new Size(125, 30);
            승인_반려_불러오기_버튼.TabIndex = 54;
            승인_반려_불러오기_버튼.Text = "불러오기";
            승인_반려_불러오기_버튼.UseVisualStyleBackColor = true;
            승인_반려_불러오기_버튼.Click += 승인_반려_불러오기_버튼_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkGray;
            panel2.Controls.Add(승인_반려_2단계_결재자_코맨트_텍스트박스);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(승인_반려_1단계_결재자_코맨트_텍스트박스);
            panel2.Controls.Add(label10);
            panel2.Controls.Add(결재_코맨트_텍스트박스);
            panel2.Controls.Add(상세정보_제목_텍스트박스);
            panel2.Controls.Add(결재자2_텍스트박스);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(결재자1_텍스트박스);
            panel2.Controls.Add(관련_업무);
            panel2.Controls.Add(관련_업무_텍스트박스);
            panel2.Controls.Add(결재자1);
            panel2.Controls.Add(결재자2);
            panel2.Controls.Add(label5);
            panel2.Location = new Point(17, 432);
            panel2.Margin = new Padding(4, 5, 4, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(1226, 235);
            panel2.TabIndex = 53;
            // 
            // 승인_반려_2단계_결재자_코맨트_텍스트박스
            // 
            승인_반려_2단계_결재자_코맨트_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            승인_반려_2단계_결재자_코맨트_텍스트박스.Location = new Point(830, 112);
            승인_반려_2단계_결재자_코맨트_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            승인_반려_2단계_결재자_코맨트_텍스트박스.Multiline = true;
            승인_반려_2단계_결재자_코맨트_텍스트박스.Name = "승인_반려_2단계_결재자_코맨트_텍스트박스";
            승인_반려_2단계_결재자_코맨트_텍스트박스.ReadOnly = true;
            승인_반려_2단계_결재자_코맨트_텍스트박스.Size = new Size(378, 110);
            승인_반려_2단계_결재자_코맨트_텍스트박스.TabIndex = 55;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.AppWorkspace;
            label9.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(830, 81);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(295, 19);
            label9.TabIndex = 54;
            label9.Text = "2단계 결재자 코맨트 ( 입력 불가 )";
            label9.TextAlign = ContentAlignment.TopCenter;
            // 
            // 승인_반려_1단계_결재자_코맨트_텍스트박스
            // 
            승인_반려_1단계_결재자_코맨트_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            승인_반려_1단계_결재자_코맨트_텍스트박스.Location = new Point(427, 112);
            승인_반려_1단계_결재자_코맨트_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            승인_반려_1단계_결재자_코맨트_텍스트박스.Multiline = true;
            승인_반려_1단계_결재자_코맨트_텍스트박스.Name = "승인_반려_1단계_결재자_코맨트_텍스트박스";
            승인_반려_1단계_결재자_코맨트_텍스트박스.ReadOnly = true;
            승인_반려_1단계_결재자_코맨트_텍스트박스.Size = new Size(378, 110);
            승인_반려_1단계_결재자_코맨트_텍스트박스.TabIndex = 53;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.AppWorkspace;
            label10.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(427, 81);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.RightToLeft = RightToLeft.Yes;
            label10.Size = new Size(295, 19);
            label10.TabIndex = 52;
            label10.Text = "1단계 결재자 코맨트 ( 입력 불가 )";
            // 
            // 결재_코맨트_텍스트박스
            // 
            결재_코맨트_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재_코맨트_텍스트박스.Location = new Point(21, 112);
            결재_코맨트_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재_코맨트_텍스트박스.Multiline = true;
            결재_코맨트_텍스트박스.Name = "결재_코맨트_텍스트박스";
            결재_코맨트_텍스트박스.ReadOnly = true;
            결재_코맨트_텍스트박스.Size = new Size(378, 110);
            결재_코맨트_텍스트박스.TabIndex = 48;
            // 
            // 상세정보_제목_텍스트박스
            // 
            상세정보_제목_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            상세정보_제목_텍스트박스.Location = new Point(335, 39);
            상세정보_제목_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            상세정보_제목_텍스트박스.Name = "상세정보_제목_텍스트박스";
            상세정보_제목_텍스트박스.ReadOnly = true;
            상세정보_제목_텍스트박스.Size = new Size(251, 32);
            상세정보_제목_텍스트박스.TabIndex = 42;
            // 
            // 결재자2_텍스트박스
            // 
            결재자2_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재자2_텍스트박스.Location = new Point(957, 39);
            결재자2_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자2_텍스트박스.Name = "결재자2_텍스트박스";
            결재자2_텍스트박스.ReadOnly = true;
            결재자2_텍스트박스.Size = new Size(251, 32);
            결재자2_텍스트박스.TabIndex = 51;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.AppWorkspace;
            label6.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(21, 10);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(91, 19);
            label6.TabIndex = 43;
            label6.Text = "결재 제목";
            // 
            // 결재자1_텍스트박스
            // 
            결재자1_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재자1_텍스트박스.Location = new Point(652, 39);
            결재자1_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자1_텍스트박스.Name = "결재자1_텍스트박스";
            결재자1_텍스트박스.ReadOnly = true;
            결재자1_텍스트박스.Size = new Size(251, 32);
            결재자1_텍스트박스.TabIndex = 50;
            // 
            // 관련_업무
            // 
            관련_업무.AutoSize = true;
            관련_업무.BackColor = SystemColors.AppWorkspace;
            관련_업무.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            관련_업무.Location = new Point(335, 10);
            관련_업무.Margin = new Padding(4, 0, 4, 0);
            관련_업무.Name = "관련_업무";
            관련_업무.Size = new Size(91, 19);
            관련_업무.TabIndex = 44;
            관련_업무.Text = "관련 업무";
            // 
            // 관련_업무_텍스트박스
            // 
            관련_업무_텍스트박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            관련_업무_텍스트박스.Location = new Point(21, 39);
            관련_업무_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            관련_업무_텍스트박스.Name = "관련_업무_텍스트박스";
            관련_업무_텍스트박스.ReadOnly = true;
            관련_업무_텍스트박스.Size = new Size(251, 32);
            관련_업무_텍스트박스.TabIndex = 49;
            // 
            // 결재자1
            // 
            결재자1.AutoSize = true;
            결재자1.BackColor = SystemColors.AppWorkspace;
            결재자1.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            결재자1.Location = new Point(652, 10);
            결재자1.Margin = new Padding(4, 0, 4, 0);
            결재자1.Name = "결재자1";
            결재자1.Size = new Size(120, 19);
            결재자1.TabIndex = 45;
            결재자1.Text = "1단계 결재자";
            // 
            // 결재자2
            // 
            결재자2.AutoSize = true;
            결재자2.BackColor = SystemColors.AppWorkspace;
            결재자2.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            결재자2.Location = new Point(957, 10);
            결재자2.Margin = new Padding(4, 0, 4, 0);
            결재자2.Name = "결재자2";
            결재자2.Size = new Size(120, 19);
            결재자2.TabIndex = 46;
            결재자2.Text = "2단계 결재자";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.AppWorkspace;
            label5.Font = new Font("굴림", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(17, 81);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(110, 19);
            label5.TabIndex = 47;
            label5.Text = "결재 코멘트";
            // 
            // 결재리스트_선택_콤보박스
            // 
            결재리스트_선택_콤보박스.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재리스트_선택_콤보박스.FormattingEnabled = true;
            결재리스트_선택_콤보박스.Items.AddRange(new object[] { "전체", "결재 중", "결재 대기", "결재 완료" });
            결재리스트_선택_콤보박스.Location = new Point(894, 13);
            결재리스트_선택_콤보박스.Margin = new Padding(4, 5, 4, 5);
            결재리스트_선택_콤보박스.Name = "결재리스트_선택_콤보박스";
            결재리스트_선택_콤보박스.Size = new Size(200, 30);
            결재리스트_선택_콤보박스.TabIndex = 52;
            // 
            // 결재_상세_정보
            // 
            결재_상세_정보.AutoSize = true;
            결재_상세_정보.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재_상세_정보.Location = new Point(17, 393);
            결재_상세_정보.Margin = new Padding(4, 0, 4, 0);
            결재_상세_정보.Name = "결재_상세_정보";
            결재_상세_정보.Size = new Size(156, 22);
            결재_상세_정보.TabIndex = 40;
            결재_상세_정보.Text = "결재 상세 정보";
            // 
            // 결재해야할_내역_그리드뷰
            // 
            결재해야할_내역_그리드뷰.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            결재해야할_내역_그리드뷰.Location = new Point(16, 51);
            결재해야할_내역_그리드뷰.Margin = new Padding(4, 5, 4, 5);
            결재해야할_내역_그리드뷰.Name = "결재해야할_내역_그리드뷰";
            결재해야할_내역_그리드뷰.RowHeadersWidth = 51;
            결재해야할_내역_그리드뷰.RowTemplate.Height = 23;
            결재해야할_내역_그리드뷰.Size = new Size(601, 323);
            결재해야할_내역_그리드뷰.TabIndex = 39;
            결재해야할_내역_그리드뷰.CellClick += 결재해야할_내역_그리드뷰_CellClick;
            // 
            // 승인_버튼
            // 
            승인_버튼.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            승인_버튼.Location = new Point(1018, 390);
            승인_버튼.Margin = new Padding(4, 5, 4, 5);
            승인_버튼.Name = "승인_버튼";
            승인_버튼.Size = new Size(107, 32);
            승인_버튼.TabIndex = 38;
            승인_버튼.Text = "승인";
            승인_버튼.UseVisualStyleBackColor = true;
            승인_버튼.Click += 승인_버튼_Click;
            // 
            // 반려_버튼
            // 
            반려_버튼.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            반려_버튼.Location = new Point(1136, 390);
            반려_버튼.Margin = new Padding(4, 5, 4, 5);
            반려_버튼.Name = "반려_버튼";
            반려_버튼.Size = new Size(107, 32);
            반려_버튼.TabIndex = 37;
            반려_버튼.Text = "반려";
            반려_버튼.UseVisualStyleBackColor = true;
            반려_버튼.Click += 반려_버튼_Click;
            // 
            // 결재_해야할_리스트
            // 
            결재_해야할_리스트.AutoSize = true;
            결재_해야할_리스트.Font = new Font("굴림", 13F, FontStyle.Regular, GraphicsUnit.Point);
            결재_해야할_리스트.Location = new Point(16, 17);
            결재_해야할_리스트.Margin = new Padding(4, 0, 4, 0);
            결재_해야할_리스트.Name = "결재_해야할_리스트";
            결재_해야할_리스트.Size = new Size(200, 22);
            결재_해야할_리스트.TabIndex = 36;
            결재_해야할_리스트.Text = "결재해야 할 리스트";
            // 
            // 결재_메인
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1280, 720);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "결재_메인";
            Text = "Form1";
            Load += 결재_메인_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)결재_등록_내역_그리드뷰).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)결재해야할_내역_그리드뷰).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox 등록_결재_상세정보_텍스트박스;
        private System.Windows.Forms.Label 결재_코멘트;
        private System.Windows.Forms.ComboBox 결재자2_콤보박스;
        private System.Windows.Forms.ComboBox 결재자1_콤보박스;
        private System.Windows.Forms.ComboBox 관련_업무_콤보박스;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox 결재_제목_텍스트박스;
        private System.Windows.Forms.Label 신규_결재_등록;
        private System.Windows.Forms.DataGridView 결재_등록_내역_그리드뷰;
        private System.Windows.Forms.Button 삭제_버튼;
        private System.Windows.Forms.Button 등록_버튼;
        private System.Windows.Forms.Label 결재_등록_내역;
        private System.Windows.Forms.ComboBox 결재리스트_선택_콤보박스;
        private System.Windows.Forms.TextBox 결재자2_텍스트박스;
        private System.Windows.Forms.TextBox 결재자1_텍스트박스;
        private System.Windows.Forms.TextBox 관련_업무_텍스트박스;
        private System.Windows.Forms.TextBox 결재_코맨트_텍스트박스;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label 결재자2;
        private System.Windows.Forms.Label 결재자1;
        private System.Windows.Forms.Label 관련_업무;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox 상세정보_제목_텍스트박스;
        private System.Windows.Forms.Label 결재_상세_정보;
        private System.Windows.Forms.DataGridView 결재해야할_내역_그리드뷰;
        private System.Windows.Forms.Button 승인_버튼;
        private System.Windows.Forms.Button 반려_버튼;
        private System.Windows.Forms.Label 결재_해야할_리스트;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button 불러오기_버튼;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox 결재_등록_내역_리스트_콤보박스;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox 조회_단계1_결재자_코맨트_텍스트박스;
        private System.Windows.Forms.Label 조회_1단계_결재자코맨트_라벨;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox 승인_반려_1단계_결재자_코맨트_텍스트박스;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox 조회_2단계_결재자_코맨트_텍스트박스;
        private System.Windows.Forms.TextBox 승인_반려_2단계_결재자_코맨트_텍스트박스;
        private System.Windows.Forms.Button 승인_반려_불러오기_버튼;
        private 상세정보창 승인_반려_상세정보창;
        private 상세정보창 결재_조회_상세정보창;
        private System.Windows.Forms.Button 초기화_버튼;
        private Panel panel3;
    }
}

