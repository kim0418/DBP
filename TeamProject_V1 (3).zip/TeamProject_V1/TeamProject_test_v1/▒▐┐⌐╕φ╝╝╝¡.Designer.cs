﻿namespace TeamProject_test_v1
{
    partial class salary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle13 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle14 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle15 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle16 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle17 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle18 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle19 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle20 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle21 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle22 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle23 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle24 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle25 = new DataGridViewCellStyle();
            top_box = new TextBox();
            member_text = new TextBox();
            member_show_datagridview = new DataGridView();
            textBox1 = new TextBox();
            extra_textbox = new TextBox();
            time_datagridview = new DataGridView();
            salary_datagridview = new DataGridView();
            month_combobox = new ComboBox();
            year_combobox = new ComboBox();
            search_button = new Button();
            tax_dataGridView = new DataGridView();
            total_datagridview = new DataGridView();
            totol_time_dataGridView = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)member_show_datagridview).BeginInit();
            ((System.ComponentModel.ISupportInitialize)time_datagridview).BeginInit();
            ((System.ComponentModel.ISupportInitialize)salary_datagridview).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tax_dataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)total_datagridview).BeginInit();
            ((System.ComponentModel.ISupportInitialize)totol_time_dataGridView).BeginInit();
            SuspendLayout();
            // 
            // top_box
            // 
            top_box.BackColor = Color.FromArgb(192, 192, 255);
            top_box.Enabled = false;
            top_box.Font = new Font("Microsoft Sans Serif", 36F, FontStyle.Bold, GraphicsUnit.Point);
            top_box.Location = new Point(0, 0);
            top_box.Multiline = true;
            top_box.Name = "top_box";
            top_box.ReadOnly = true;
            top_box.Size = new Size(845, 85);
            top_box.TabIndex = 1;
            top_box.Text = "급여명세서";
            top_box.TextAlign = HorizontalAlignment.Center;
            // 
            // member_text
            // 
            member_text.BackColor = SystemColors.Menu;
            member_text.BorderStyle = BorderStyle.None;
            member_text.Font = new Font("맑은 고딕", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            member_text.Location = new Point(0, 93);
            member_text.Name = "member_text";
            member_text.ReadOnly = true;
            member_text.Size = new Size(125, 24);
            member_text.TabIndex = 2;
            member_text.Text = "▣ 사원정보";
            // 
            // member_show_datagridview
            // 
            member_show_datagridview.AllowUserToAddRows = false;
            member_show_datagridview.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            member_show_datagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            member_show_datagridview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            member_show_datagridview.BackgroundColor = SystemColors.ScrollBar;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Control;
            dataGridViewCellStyle2.Font = new Font("맑은 고딕", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            member_show_datagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            member_show_datagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.Window;
            dataGridViewCellStyle3.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            member_show_datagridview.DefaultCellStyle = dataGridViewCellStyle3;
            member_show_datagridview.Location = new Point(0, 126);
            member_show_datagridview.Name = "member_show_datagridview";
            member_show_datagridview.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("맑은 고딕", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            member_show_datagridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            member_show_datagridview.RowHeadersVisible = false;
            member_show_datagridview.RowHeadersWidth = 51;
            member_show_datagridview.RowTemplate.Height = 29;
            member_show_datagridview.Size = new Size(845, 61);
            member_show_datagridview.TabIndex = 3;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Menu;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("맑은 고딕", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            textBox1.Location = new Point(0, 193);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(167, 24);
            textBox1.TabIndex = 4;
            textBox1.Text = "▣ 월급 세부 내역";
            // 
            // extra_textbox
            // 
            extra_textbox.BackColor = SystemColors.Menu;
            extra_textbox.BorderStyle = BorderStyle.None;
            extra_textbox.Font = new Font("맑은 고딕", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            extra_textbox.Location = new Point(0, 548);
            extra_textbox.Name = "extra_textbox";
            extra_textbox.ReadOnly = true;
            extra_textbox.Size = new Size(207, 24);
            extra_textbox.TabIndex = 4;
            extra_textbox.Text = "▣ 근무일 및 근무시간";
            // 
            // time_datagridview
            // 
            time_datagridview.AllowUserToAddRows = false;
            time_datagridview.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            time_datagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            time_datagridview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            time_datagridview.BackgroundColor = SystemColors.Window;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = SystemColors.Control;
            dataGridViewCellStyle6.Font = new Font("맑은 고딕", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            time_datagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            time_datagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = SystemColors.Window;
            dataGridViewCellStyle7.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle7.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            time_datagridview.DefaultCellStyle = dataGridViewCellStyle7;
            time_datagridview.Location = new Point(0, 639);
            time_datagridview.Name = "time_datagridview";
            time_datagridview.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = SystemColors.Control;
            dataGridViewCellStyle8.Font = new Font("맑은 고딕", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            time_datagridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            time_datagridview.RowHeadersVisible = false;
            time_datagridview.RowHeadersWidth = 51;
            time_datagridview.RowTemplate.Height = 29;
            time_datagridview.Size = new Size(845, 299);
            time_datagridview.TabIndex = 3;
            // 
            // salary_datagridview
            // 
            salary_datagridview.AllowUserToAddRows = false;
            salary_datagridview.AllowUserToDeleteRows = false;
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleCenter;
            salary_datagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            salary_datagridview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            salary_datagridview.BackgroundColor = SystemColors.Window;
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = SystemColors.Control;
            dataGridViewCellStyle10.Font = new Font("맑은 고딕", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle10.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.True;
            salary_datagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            salary_datagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = SystemColors.Window;
            dataGridViewCellStyle11.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle11.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.False;
            salary_datagridview.DefaultCellStyle = dataGridViewCellStyle11;
            salary_datagridview.Location = new Point(0, 223);
            salary_datagridview.Name = "salary_datagridview";
            salary_datagridview.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = SystemColors.Control;
            dataGridViewCellStyle12.Font = new Font("맑은 고딕", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle12.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.True;
            salary_datagridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            salary_datagridview.RowHeadersVisible = false;
            salary_datagridview.RowHeadersWidth = 51;
            salary_datagridview.RowTemplate.Height = 29;
            salary_datagridview.Size = new Size(428, 319);
            salary_datagridview.TabIndex = 3;
            // 
            // month_combobox
            // 
            month_combobox.FormattingEnabled = true;
            month_combobox.Location = new Point(626, 91);
            month_combobox.Name = "month_combobox";
            month_combobox.Size = new Size(151, 28);
            month_combobox.TabIndex = 5;
            // 
            // year_combobox
            // 
            year_combobox.FormattingEnabled = true;
            year_combobox.Location = new Point(469, 91);
            year_combobox.Name = "year_combobox";
            year_combobox.Size = new Size(151, 28);
            year_combobox.TabIndex = 6;
            // 
            // search_button
            // 
            search_button.BackColor = Color.FromArgb(128, 128, 255);
            search_button.Font = new Font("맑은 고딕", 9F, FontStyle.Bold, GraphicsUnit.Point);
            search_button.ForeColor = Color.White;
            search_button.Location = new Point(783, 91);
            search_button.Name = "search_button";
            search_button.Size = new Size(62, 29);
            search_button.TabIndex = 7;
            search_button.Text = "조회";
            search_button.UseVisualStyleBackColor = false;
            search_button.Click += search_button_Click;
            // 
            // tax_dataGridView
            // 
            tax_dataGridView.AllowUserToAddRows = false;
            tax_dataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle13.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tax_dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            tax_dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tax_dataGridView.BackgroundColor = SystemColors.Window;
            dataGridViewCellStyle14.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = SystemColors.Control;
            dataGridViewCellStyle14.Font = new Font("맑은 고딕", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle14.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = DataGridViewTriState.True;
            tax_dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            tax_dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle15.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = SystemColors.Window;
            dataGridViewCellStyle15.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle15.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = DataGridViewTriState.False;
            tax_dataGridView.DefaultCellStyle = dataGridViewCellStyle15;
            tax_dataGridView.Location = new Point(427, 223);
            tax_dataGridView.Name = "tax_dataGridView";
            tax_dataGridView.ReadOnly = true;
            dataGridViewCellStyle16.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = SystemColors.Control;
            dataGridViewCellStyle16.Font = new Font("맑은 고딕", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle16.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = DataGridViewTriState.True;
            tax_dataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            tax_dataGridView.RowHeadersVisible = false;
            tax_dataGridView.RowHeadersWidth = 51;
            tax_dataGridView.RowTemplate.Height = 29;
            tax_dataGridView.Size = new Size(418, 319);
            tax_dataGridView.TabIndex = 3;
            // 
            // total_datagridview
            // 
            total_datagridview.AllowUserToAddRows = false;
            total_datagridview.AllowUserToDeleteRows = false;
            dataGridViewCellStyle17.Alignment = DataGridViewContentAlignment.MiddleCenter;
            total_datagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            total_datagridview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            total_datagridview.BackgroundColor = SystemColors.Window;
            dataGridViewCellStyle18.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = SystemColors.Control;
            dataGridViewCellStyle18.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle18.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = DataGridViewTriState.True;
            total_datagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            total_datagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle19.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = SystemColors.Window;
            dataGridViewCellStyle19.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle19.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle19.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = DataGridViewTriState.False;
            total_datagridview.DefaultCellStyle = dataGridViewCellStyle19;
            total_datagridview.Location = new Point(0, 482);
            total_datagridview.Name = "total_datagridview";
            total_datagridview.ReadOnly = true;
            dataGridViewCellStyle20.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = SystemColors.Control;
            dataGridViewCellStyle20.Font = new Font("맑은 고딕", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle20.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = DataGridViewTriState.True;
            total_datagridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle20;
            total_datagridview.RowHeadersVisible = false;
            total_datagridview.RowHeadersWidth = 51;
            dataGridViewCellStyle21.Alignment = DataGridViewContentAlignment.MiddleCenter;
            total_datagridview.RowsDefaultCellStyle = dataGridViewCellStyle21;
            total_datagridview.RowTemplate.Height = 29;
            total_datagridview.Size = new Size(845, 60);
            total_datagridview.TabIndex = 8;
            // 
            // totol_time_dataGridView
            // 
            totol_time_dataGridView.AllowUserToAddRows = false;
            totol_time_dataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle22.Alignment = DataGridViewContentAlignment.MiddleCenter;
            totol_time_dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle22;
            totol_time_dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            totol_time_dataGridView.BackgroundColor = SystemColors.Window;
            dataGridViewCellStyle23.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = SystemColors.Control;
            dataGridViewCellStyle23.Font = new Font("맑은 고딕", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle23.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = DataGridViewTriState.True;
            totol_time_dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            totol_time_dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle24.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = SystemColors.Window;
            dataGridViewCellStyle24.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle24.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = DataGridViewTriState.False;
            totol_time_dataGridView.DefaultCellStyle = dataGridViewCellStyle24;
            totol_time_dataGridView.Location = new Point(0, 579);
            totol_time_dataGridView.Name = "totol_time_dataGridView";
            totol_time_dataGridView.ReadOnly = true;
            dataGridViewCellStyle25.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle25.BackColor = SystemColors.Control;
            dataGridViewCellStyle25.Font = new Font("맑은 고딕", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle25.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = DataGridViewTriState.True;
            totol_time_dataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle25;
            totol_time_dataGridView.RowHeadersVisible = false;
            totol_time_dataGridView.RowHeadersWidth = 51;
            totol_time_dataGridView.RowTemplate.Height = 29;
            totol_time_dataGridView.Size = new Size(845, 60);
            totol_time_dataGridView.TabIndex = 9;
            // 
            // salary
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(845, 939);
            Controls.Add(totol_time_dataGridView);
            Controls.Add(total_datagridview);
            Controls.Add(search_button);
            Controls.Add(year_combobox);
            Controls.Add(month_combobox);
            Controls.Add(extra_textbox);
            Controls.Add(textBox1);
            Controls.Add(tax_dataGridView);
            Controls.Add(salary_datagridview);
            Controls.Add(time_datagridview);
            Controls.Add(member_show_datagridview);
            Controls.Add(member_text);
            Controls.Add(top_box);
            DoubleBuffered = true;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "salary";
            Text = "급여명세서";
            Load += salary_Load;
            ((System.ComponentModel.ISupportInitialize)member_show_datagridview).EndInit();
            ((System.ComponentModel.ISupportInitialize)time_datagridview).EndInit();
            ((System.ComponentModel.ISupportInitialize)salary_datagridview).EndInit();
            ((System.ComponentModel.ISupportInitialize)tax_dataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)total_datagridview).EndInit();
            ((System.ComponentModel.ISupportInitialize)totol_time_dataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox top_box;
        private TextBox member_text;
        private DataGridView member_show_datagridview;
        private TextBox textBox1;
        private TextBox extra_textbox;
        private DataGridView time_datagridview;
        private DataGridView salary_datagridview;
        private ComboBox month_combobox;
        private ComboBox year_combobox;
        private Button search_button;
        private DataGridView tax_dataGridView;
        private DataGridView total_datagridview;
        private DataGridView totol_time_dataGridView;
    }
}