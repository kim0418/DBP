﻿namespace TeamProject_test_v1
{
    partial class 상세정보창
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            groupBox3 = new GroupBox();
            결재자2_코맨트_텍스트박스 = new TextBox();
            결재자2_승인여부_텍스트박스 = new TextBox();
            결재자2_결재일_텍스트박스 = new TextBox();
            결재자2_이름_텍스트박스 = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label10 = new Label();
            label6 = new Label();
            groupBox2 = new GroupBox();
            결재자1_코맨트_텍스트박스 = new TextBox();
            label2 = new Label();
            label11 = new Label();
            결재자1_승인여부_텍스트박스 = new TextBox();
            결재자1_결재일_텍스트박스 = new TextBox();
            결재자1_이름_텍스트박스 = new TextBox();
            label1 = new Label();
            이름 = new Label();
            결재제목_텍스트박스 = new TextBox();
            label13 = new Label();
            기안자_텍스트박스 = new TextBox();
            label12 = new Label();
            최종_텍스트박스 = new TextBox();
            label9 = new Label();
            label5 = new Label();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Controls.Add(groupBox2);
            groupBox1.Controls.Add(결재제목_텍스트박스);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(기안자_텍스트박스);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(최종_텍스트박스);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label5);
            groupBox1.Location = new Point(4, 5);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(574, 323);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "결재자 상세정보";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(결재자2_코맨트_텍스트박스);
            groupBox3.Controls.Add(결재자2_승인여부_텍스트박스);
            groupBox3.Controls.Add(결재자2_결재일_텍스트박스);
            groupBox3.Controls.Add(결재자2_이름_텍스트박스);
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(label6);
            groupBox3.Location = new Point(160, 163);
            groupBox3.Margin = new Padding(4, 5, 4, 5);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4, 5, 4, 5);
            groupBox3.Size = new Size(399, 150);
            groupBox3.TabIndex = 23;
            groupBox3.TabStop = false;
            groupBox3.Text = "2단계 결재자";
            // 
            // 결재자2_코맨트_텍스트박스
            // 
            결재자2_코맨트_텍스트박스.Location = new Point(260, 59);
            결재자2_코맨트_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자2_코맨트_텍스트박스.Multiline = true;
            결재자2_코맨트_텍스트박스.Name = "결재자2_코맨트_텍스트박스";
            결재자2_코맨트_텍스트박스.ReadOnly = true;
            결재자2_코맨트_텍스트박스.Size = new Size(127, 86);
            결재자2_코맨트_텍스트박스.TabIndex = 11;
            // 
            // 결재자2_승인여부_텍스트박스
            // 
            결재자2_승인여부_텍스트박스.Location = new Point(123, 59);
            결재자2_승인여부_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자2_승인여부_텍스트박스.Name = "결재자2_승인여부_텍스트박스";
            결재자2_승인여부_텍스트박스.ReadOnly = true;
            결재자2_승인여부_텍스트박스.Size = new Size(127, 27);
            결재자2_승인여부_텍스트박스.TabIndex = 10;
            // 
            // 결재자2_결재일_텍스트박스
            // 
            결재자2_결재일_텍스트박스.Location = new Point(123, 116);
            결재자2_결재일_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자2_결재일_텍스트박스.Name = "결재자2_결재일_텍스트박스";
            결재자2_결재일_텍스트박스.ReadOnly = true;
            결재자2_결재일_텍스트박스.Size = new Size(127, 27);
            결재자2_결재일_텍스트박스.TabIndex = 17;
            // 
            // 결재자2_이름_텍스트박스
            // 
            결재자2_이름_텍스트박스.Location = new Point(6, 57);
            결재자2_이름_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자2_이름_텍스트박스.Name = "결재자2_이름_텍스트박스";
            결재자2_이름_텍스트박스.ReadOnly = true;
            결재자2_이름_텍스트박스.Size = new Size(94, 27);
            결재자2_이름_텍스트박스.TabIndex = 9;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(121, 34);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(74, 20);
            label7.TabIndex = 13;
            label7.Text = "승인 여부";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(4, 32);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(39, 20);
            label8.TabIndex = 12;
            label8.Text = "이름";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(121, 91);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(54, 20);
            label10.TabIndex = 18;
            label10.Text = "결재일";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(257, 34);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(54, 20);
            label6.TabIndex = 14;
            label6.Text = "코맨트";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(결재자1_코맨트_텍스트박스);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(결재자1_승인여부_텍스트박스);
            groupBox2.Controls.Add(결재자1_결재일_텍스트박스);
            groupBox2.Controls.Add(결재자1_이름_텍스트박스);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(이름);
            groupBox2.Location = new Point(160, 14);
            groupBox2.Margin = new Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 5, 4, 5);
            groupBox2.Size = new Size(399, 150);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "1단계 결재자";
            // 
            // 결재자1_코맨트_텍스트박스
            // 
            결재자1_코맨트_텍스트박스.Location = new Point(261, 55);
            결재자1_코맨트_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자1_코맨트_텍스트박스.Multiline = true;
            결재자1_코맨트_텍스트박스.Name = "결재자1_코맨트_텍스트박스";
            결재자1_코맨트_텍스트박스.ReadOnly = true;
            결재자1_코맨트_텍스트박스.Size = new Size(127, 86);
            결재자1_코맨트_텍스트박스.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(122, 30);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(74, 20);
            label2.TabIndex = 1;
            label2.Text = "승인 여부";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(258, 30);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(54, 20);
            label11.TabIndex = 20;
            label11.Text = "코맨트";
            // 
            // 결재자1_승인여부_텍스트박스
            // 
            결재자1_승인여부_텍스트박스.Location = new Point(125, 55);
            결재자1_승인여부_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자1_승인여부_텍스트박스.Name = "결재자1_승인여부_텍스트박스";
            결재자1_승인여부_텍스트박스.ReadOnly = true;
            결재자1_승인여부_텍스트박스.Size = new Size(127, 27);
            결재자1_승인여부_텍스트박스.TabIndex = 7;
            // 
            // 결재자1_결재일_텍스트박스
            // 
            결재자1_결재일_텍스트박스.Location = new Point(125, 114);
            결재자1_결재일_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자1_결재일_텍스트박스.Name = "결재자1_결재일_텍스트박스";
            결재자1_결재일_텍스트박스.ReadOnly = true;
            결재자1_결재일_텍스트박스.Size = new Size(127, 27);
            결재자1_결재일_텍스트박스.TabIndex = 21;
            // 
            // 결재자1_이름_텍스트박스
            // 
            결재자1_이름_텍스트박스.Location = new Point(8, 55);
            결재자1_이름_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재자1_이름_텍스트박스.Name = "결재자1_이름_텍스트박스";
            결재자1_이름_텍스트박스.ReadOnly = true;
            결재자1_이름_텍스트박스.Size = new Size(98, 27);
            결재자1_이름_텍스트박스.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(122, 89);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(54, 20);
            label1.TabIndex = 22;
            label1.Text = "결재일";
            // 
            // 이름
            // 
            이름.AutoSize = true;
            이름.Location = new Point(5, 30);
            이름.Margin = new Padding(4, 0, 4, 0);
            이름.Name = "이름";
            이름.Size = new Size(39, 20);
            이름.TabIndex = 0;
            이름.Text = "이름";
            // 
            // 결재제목_텍스트박스
            // 
            결재제목_텍스트박스.Location = new Point(10, 138);
            결재제목_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            결재제목_텍스트박스.Multiline = true;
            결재제목_텍스트박스.Name = "결재제목_텍스트박스";
            결재제목_텍스트박스.ReadOnly = true;
            결재제목_텍스트박스.Size = new Size(127, 64);
            결재제목_텍스트박스.TabIndex = 26;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(8, 106);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(74, 20);
            label13.TabIndex = 25;
            label13.Text = "결재 제목";
            // 
            // 기안자_텍스트박스
            // 
            기안자_텍스트박스.Location = new Point(10, 65);
            기안자_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            기안자_텍스트박스.Name = "기안자_텍스트박스";
            기안자_텍스트박스.ReadOnly = true;
            기안자_텍스트박스.Size = new Size(127, 27);
            기안자_텍스트박스.TabIndex = 24;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(8, 33);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(54, 20);
            label12.TabIndex = 23;
            label12.Text = "기안자";
            // 
            // 최종_텍스트박스
            // 
            최종_텍스트박스.Location = new Point(10, 257);
            최종_텍스트박스.Margin = new Padding(4, 5, 4, 5);
            최종_텍스트박스.Name = "최종_텍스트박스";
            최종_텍스트박스.ReadOnly = true;
            최종_텍스트박스.Size = new Size(127, 27);
            최종_텍스트박스.TabIndex = 16;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(8, 225);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(99, 20);
            label9.TabIndex = 15;
            label9.Text = "최종승인여부";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(8, 215);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 4;
            // 
            // 상세정보창
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(groupBox1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "상세정보창";
            Size = new Size(574, 323);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label 이름;
        private System.Windows.Forms.TextBox 결재자1_이름_텍스트박스;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox 결재자1_결재일_텍스트박스;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox 결재자1_코맨트_텍스트박스;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox 결재자2_결재일_텍스트박스;
        private System.Windows.Forms.TextBox 최종_텍스트박스;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox 결재자2_코맨트_텍스트박스;
        private System.Windows.Forms.TextBox 결재자2_승인여부_텍스트박스;
        private System.Windows.Forms.TextBox 결재자2_이름_텍스트박스;
        private System.Windows.Forms.TextBox 결재자1_승인여부_텍스트박스;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox 기안자_텍스트박스;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox 결재제목_텍스트박스;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}
