﻿namespace TeamProject_test_v1
{
    partial class 업무마스터_수정
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.modify_button = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.after_small_textbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.after_mid_textbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.after_big_textbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.before_big_combo = new System.Windows.Forms.ComboBox();
            this.before_mid_combo = new System.Windows.Forms.ComboBox();
            this.before_small_combo = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // modify_button
            // 
            this.modify_button.Location = new System.Drawing.Point(470, 180);
            this.modify_button.Name = "modify_button";
            this.modify_button.Size = new System.Drawing.Size(94, 36);
            this.modify_button.TabIndex = 15;
            this.modify_button.Text = "수정하기";
            this.modify_button.UseVisualStyleBackColor = true;
            this.modify_button.Click += new System.EventHandler(this.modify_button_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(771, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 25);
            this.label3.TabIndex = 12;
            this.label3.Text = "소분류";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(470, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "중분류";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(171, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "대분류";
            // 
            // after_small_textbox
            // 
            this.after_small_textbox.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.after_small_textbox.Location = new System.Drawing.Point(858, 118);
            this.after_small_textbox.Name = "after_small_textbox";
            this.after_small_textbox.Size = new System.Drawing.Size(170, 32);
            this.after_small_textbox.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(771, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 25);
            this.label4.TabIndex = 20;
            this.label4.Text = "소분류";
            // 
            // after_mid_textbox
            // 
            this.after_mid_textbox.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.after_mid_textbox.Location = new System.Drawing.Point(560, 120);
            this.after_mid_textbox.Name = "after_mid_textbox";
            this.after_mid_textbox.Size = new System.Drawing.Size(170, 32);
            this.after_mid_textbox.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(470, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 25);
            this.label5.TabIndex = 18;
            this.label5.Text = "중분류";
            // 
            // after_big_textbox
            // 
            this.after_big_textbox.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.after_big_textbox.Location = new System.Drawing.Point(260, 118);
            this.after_big_textbox.Name = "after_big_textbox";
            this.after_big_textbox.Size = new System.Drawing.Size(170, 32);
            this.after_big_textbox.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(171, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 25);
            this.label6.TabIndex = 16;
            this.label6.Text = "대분류";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(40, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 32);
            this.label7.TabIndex = 22;
            this.label7.Text = "수정 전";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(40, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 32);
            this.label8.TabIndex = 23;
            this.label8.Text = "수정 후";
            // 
            // before_big_combo
            // 
            this.before_big_combo.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.before_big_combo.FormattingEnabled = true;
            this.before_big_combo.Location = new System.Drawing.Point(260, 43);
            this.before_big_combo.Name = "before_big_combo";
            this.before_big_combo.Size = new System.Drawing.Size(170, 33);
            this.before_big_combo.TabIndex = 24;
            this.before_big_combo.SelectedIndexChanged += new System.EventHandler(this.big_category_combobox_SelectedIndexChanged);
            this.before_big_combo.Click += new System.EventHandler(this.big_category_combobox_Click);
            // 
            // before_mid_combo
            // 
            this.before_mid_combo.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.before_mid_combo.FormattingEnabled = true;
            this.before_mid_combo.Location = new System.Drawing.Point(560, 42);
            this.before_mid_combo.Name = "before_mid_combo";
            this.before_mid_combo.Size = new System.Drawing.Size(170, 33);
            this.before_mid_combo.TabIndex = 25;
            this.before_mid_combo.SelectedIndexChanged += new System.EventHandler(this.mid_category_combobox_SelectedIndexChanged);
            // 
            // before_small_combo
            // 
            this.before_small_combo.Font = new System.Drawing.Font("맑은 고딕", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.before_small_combo.FormattingEnabled = true;
            this.before_small_combo.Location = new System.Drawing.Point(858, 44);
            this.before_small_combo.Name = "before_small_combo";
            this.before_small_combo.Size = new System.Drawing.Size(170, 33);
            this.before_small_combo.TabIndex = 26;
            // 
            // 업무마스터_수정
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 253);
            this.Controls.Add(this.before_small_combo);
            this.Controls.Add(this.before_mid_combo);
            this.Controls.Add(this.before_big_combo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.after_small_textbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.after_mid_textbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.after_big_textbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.modify_button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "업무마스터_수정";
            this.Text = "업무마스터_수정";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.업무마스터_수정_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button modify_button;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox after_small_textbox;
        private Label label4;
        private TextBox after_mid_textbox;
        private Label label5;
        private TextBox after_big_textbox;
        private Label label6;
        private Label label7;
        private Label label8;
        private ComboBox before_big_combo;
        private ComboBox before_mid_combo;
        private ComboBox before_small_combo;
    }
}